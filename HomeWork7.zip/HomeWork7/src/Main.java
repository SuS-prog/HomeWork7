import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Phone> phones = new ArrayList<>();

        phones.add(new Phone("Apple", "iPhone 14", 799));
        phones.add(new Phone("Xiaomi", "Poco X5 Pro", 309));
        phones.add(new Phone("Samsung", "Galaxy S23", 799));
        phones.add(new Phone("Apple", "iPhone 14 Pro", 1399));
        phones.add(new Phone("Apple", "iPhone 14 Pro Max", 1549));


        List<Phone> appleList = phones.stream()
                .filter(o -> o.manufacture.equals("Apple"))
                //.map(Phone::getManufacture)
                .collect(Collectors.toList());
        System.out.println(appleList.toString());

        Collections.sort(phones);
        System.out.println(phones);

    }
}
