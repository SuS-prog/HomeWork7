public class Phone implements Comparable<Phone>{
    String manufacture;
    String model;
    int price;

    public Phone(String manufacture, String model, int price){
        this.manufacture = manufacture;
        this.model = model;
        this.price = price;
    }

    @Override
    public int compareTo(Phone otherPhone) {
        return Integer.compare(this.price, otherPhone.price);
    }

    public String toString(){
        return "Phone{ " +
                "Manufacture: " + manufacture +
                " Model: " + model +
                " Price: " + price;
    }
}
